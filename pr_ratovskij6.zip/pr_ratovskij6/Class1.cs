﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr_ratovskij6
{
    public class Employee
    {
        public string LastName { get; set; }  // Фамилия
        public string FirstName { get; set; } // Имя
        public string MiddleName { get; set; } // Отчество
        public string Gender { get; set; } // Пол (м/ж)
        public int Age { get; set; } // Возраст
        public int Salary { get; set; } // Размер зарплаты
        public Employee(string lastName, string firstName, string middleName, string gender, int age, int salary)
        {
            LastName = lastName;
            FirstName = firstName;
            MiddleName = middleName;
            Gender = gender;
            Age = age;
            Salary = salary;
        }
        public override string ToString()
        {
            return $"{LastName} {FirstName} {MiddleName}, Пол: {Gender}, Возраст: {Age}, Зарплата: {Salary}";
        }
    }
}
