﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace pr_ratovskij6
{
    class Program
    {
        static void Main(string[] args)
        {
            // Путь к файлу с данными сотрудников
            string filePath = "t.txt";
            // колекции мужчин и женщин
            Queue<Employee> maleQueue = new Queue<Employee>();
            Queue<Employee> femaleQueue = new Queue<Employee>();
            try
            {
                // Чтение данных из файла
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] parts = line.Split(' ');
                        if (parts.Length == 6)
                        {
                            string lastName = parts[0];
                            string firstName = parts[1];
                            string middleName = parts[2];
                            string gender = parts[3];
                            int age = int.Parse(parts[4]);
                            int salary = int.Parse(parts[5]);
                            // Создание объекта
                            Employee employee = new Employee(lastName, firstName, middleName, gender, age, salary);
                            // Добавление в соответствующую очередь
                            if (gender.ToLower() == "м")
                            {
                                maleQueue.Enqueue(employee);
                            }
                            else if (gender.ToLower() == "ж")
                            {
                                femaleQueue.Enqueue(employee);
                            }
                        }
                    }
                }
                // Вывод данных о мужчинах
                Console.WriteLine("Сотрудники-мужчины:");
                while (maleQueue.Count > 0)
                {
                    Console.WriteLine(maleQueue.Dequeue());
                }
                // Вывод данных о женщинах
                Console.WriteLine("Сотрудники-женщины:");
                while (femaleQueue.Count > 0)
                {
                    Console.WriteLine(femaleQueue.Dequeue());
                }
            }
            catch (Exception)
            {
                Console.WriteLine($"Ошибка");
            }
            Console.ReadKey();
        }
    }
}
