﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr_ratovsij8
{
    class People
    {
        private string familia;
        private string imya;
        private string otchestvo;
        private int age;
        private int zp;
        private string gender;
        public People(string familia, string imya, string otchestvo, int age, int zp, string gender)
        {
            this.familia = familia;
            this.imya = imya;
            this.otchestvo = otchestvo;
            this.age = age;
            this.zp = zp;
            this.gender = gender;
        }
        public int Age { get => age; set => age = value; }
        public int Zp { get => zp; set => zp = value; }
        public string Imya { get => imya; set => imya = value; }
        public string Familia { get => familia; set => familia = value; }
        public string Otchestvo { get => otchestvo; set => otchestvo = value; }
        public string Gender { get => gender; set => gender = value; }
        public override string ToString()
        {
            return $"{familia} {imya} {otchestvo} {gender} {age} {zp}";
        }
    }
}
