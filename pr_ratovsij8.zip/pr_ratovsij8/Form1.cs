﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace pr_ratovsij8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Queue<string> younger30 = new Queue<string>();
        Queue<string> older30 = new Queue<string>();
        private void button1_Click(object sender, EventArgs e)
        {
            if (File.Exists("t.txt"))
            {
                try
                {
                    StreamReader sw = new StreamReader("t.txt");
                    string[] lines = File.ReadAllLines("t.txt");
                    var people = new List<People>();
                    while (true)
                    {
                        string line = sw.ReadLine();
                        if (line == null)
                        {
                            break;
                        }
                        string[] parts = line.Split(' ');
                        if (parts.Length == 6)
                        {
                            string familia = parts[0];
                            string imya = parts[1];
                            string otchestvo = parts[2];
                            string gender = parts[3];
                            int age = int.Parse(parts[4]);
                            int zp = int.Parse(parts[5]);

                            people.Add(new People(familia, imya, otchestvo, age, zp, gender));
                        }
                    }
                    var younger = people.Where(p => p.Age < 30);
                    var older = people.Where(p => p.Age >= 30);
                    foreach (var person in younger)
                    {
                        younger30.Enqueue(person.ToString());
                    }
                    foreach (var person in older)
                    {
                        older30.Enqueue(person.ToString());
                    }
                    listBox1.Items.Clear();
                    while (younger30.Count > 0)
                    {
                        listBox1.Items.Add(younger30.Dequeue());
                    }
                    while (older30.Count > 0)
                    {
                        listBox1.Items.Add(older30.Dequeue());
                    }
                }
                catch
                {
                    MessageBox.Show($"Произошла ошибка", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Файл не найден!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
